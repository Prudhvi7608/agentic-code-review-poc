# tools/code_review_tool.py
from langchain.tools import tool

@tool
def review_code(code: str) -> str:
    """Reviews Python code and suggests improvements including logging, structure, error handling, and best practices."""
    return f"""
Please review this code:

{code}

Check for:
- Logging
- Structure
- Error handling
- Best practices
"""
